from multiprocessing import Process
import time

#创建process 进程
# def test():
#     while True:
#         print("----test----")
#         time.sleep(1)
#
# if __name__ == '__main__':
#     p=Process(target=test)
#     p.start()  #让这个进程开始执行test函数里的代码
#
#     while True:
#         print('---main--')
#         time.sleep(1)


#主进程与子进程
# def test():
#     # while True:
#    for i in range(5):
#         print("----test----")
#         time.sleep(0.5)
#
# if __name__ == '__main__':
#     p=Process(target=test)
#     p.start()  #让这个进程开始执行test函数里的代码
#



#jion主进程等待子进程
# import random
# def test():
#     for i in range(random.randint(1,5)):
#         print("----%d----"%i)
#         time.sleep(0.5)
#
# if __name__ == '__main__':
#
#     p=Process(target=test)
#
#     p.start()
#
#     # p.join()    #等到子进程停止结束之后，才执行
#                 #堵塞
#
#     # p.join(1)       #只等待一秒
#                     # jion[outtime(超时时间)]
#
#     p.terminate()   #kill 子进程
#     print('-----main-----')


import time

# print(time.ctime())    #当前时间
#子类创建进程
class MyProcess(Process):
    #重写run方法
    def run(self):
        while True:
            print('--run---')
            time.sleep(0.3)

if __name__=='__main__':
    p=MyProcess()
    p.start()

    while True:
        print('---main---')
        time.sleep(0.2)