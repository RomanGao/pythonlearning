import time
import os
from multiprocessing import Pool

def worker(num):
    for i in range(5):
        print("===pid=%d==num=%d="%(os.getpid(), num))
        time.sleep(1)

if __name__ == '__main__':
    #3表示 进程池中对多有3个进程一起执行
    pool = Pool(3)

    for i in range(10):
        print("---%d---"%i)
        pool.apply(worker, (i,))     #以堵塞的方式运行，用排队的形式执行


    pool.close()#关闭进程池，相当于　不能够再次添加新任务了
    pool.join()