from multiprocessing import Pool
import os, time, random


def worker(msg):
    t_start = time.time()
    print('%s开始执行，进程为%d' % (msg, os.getpid()))  # os.getpid(pid) 返回pid进程的group id.如果pid为0,返回当前进程的group i

    time.sleep(random.random() * 2)  # random.random()生成0~1之间的浮点数
    t_stop = time.time()

    print(msg, '执行完毕，耗时%0.2f' % (t_stop - t_start))


if __name__ == '__main__':

    pool = Pool(3)  # 定义一个进程池，最大进程数为3

    for i in range(0, 10):
        # Pool.apply_async(要调用的目标，（传给目标的参数元祖,）)
        # 每此循环将会用空闲出来的子进程去调用目标
        pool.apply_async(worker, (i,))

    print('-------start------')

    pool.close()  # 关闭进程池，关闭后po不再接受新的请求
    pool.join()  # 等待po中所有子进程执行完成，必须放在close语句之后

    print('------end----')

# def worker(num):
#     for i in range(5):
#         print("===pid=%d==num=%d="%(os.getpid(), num))
#         time.sleep(1)
#
# if __name__ == '__main__':
#     #3表示 进程池中对多有3个进程一起执行
#     pool = Pool(3)
#
#     for i in range(10):
#         print("---%d---"%i)
#         #向进程池中添加任务
#         #注意：如果添加的任务数量超过了　进程池中进程的个数的话，那么不会导致添加不进入
#         #       添加到进程中的任务　如果还没有被执行的话，那么此时　他们会等待进程池中的
#         #       进程完成一个任务之后，会自动的去用刚刚的那个进程　完成当前的新任务
#         pool.apply_async(worker, (i,))
#
#
#     pool.close()#关闭进程池，相当于　不能够再次添加新任务了
#     pool.join()#主进程　创建／添加　任务后，主进程　默认不会等待进程池中的任务执行完后才结束
#                 #而是　当主进程的任务做完之后　立马结束，，，如果这个地方没join,会导致
#                 #进程池中的任务不会执行
