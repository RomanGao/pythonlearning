from multiprocessing import Queue
'''
if __name__=='__main__':

    q=Queue(3)
    print(q.qsize())

    q.put('haha-1')
    print(q.qsize())
    q.put('haha-2')
    q.put('haha-3')
    # q.put('haha-4')   #满了
    print(q.qsize())

    print(q.get())
    q.qsize()
    print(q.qsize())

    print(q.get())
    q.qsize()
    print(q.qsize())

    print(q.empty())
    print(q.full())


    print(q.get_nowait())  #获取不会等，没有数据也不等，直接报异常
    q.put_nowait(100)  #添加不会等，满了也不会等，直接报错

'''
import os,time,random
from multiprocessing import Queue,Process

#写入数据
def write(q):
    for value in ['A','B','C']:
        print('Put %s to queue...'%value)
        q.put(value)
        time.sleep(random.random())

#读出数据
def read(q):
    while True:
        if not q.empty():
            value=q.get(True)
            print('Get %s from queue'%value)
            time.sleep(random.random())
        else:
            break

from multiprocessing import Manager,Pool
if __name__=='__main__':

    # q=Queue()   #任何数量队列
    q=Manager().Queue()   #队列进程池之间的任务通信

    pw=Process(target=write,args=(q,))
    pr=Process(target=read,args=(q,))

    #启动子进程写
    pw.start()
    #等待写完
    pw.join()


    #启动子进程
    pr.start()
    pr.join()

    print('所有数据读写完成。。。')

