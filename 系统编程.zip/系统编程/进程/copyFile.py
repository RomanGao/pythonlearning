from multiprocessing import Pool,Manager
import os

#添加和删除文件夹
# os.mkdir('copytest')
# os.rmdir('copytest')

def copyFileTask(name,oldFolder,newFolderName,queue):
    #完成copy一个文件的功能
    fr=open(oldFolder+"/"+name)
    fw=open(newFolderName+"/"+name,'w')
    # print(name+'---')
    content=fr.read()
    fw.write(content)
    # print('=======')
    fr.close()
    fw.close()
    queue.put(name)

def main():

    #1 获取一个文件夹的名字
    oldFolderName=input('请输入文件夹的名字：')

    #2 创建一个文件夹
    newFolderName=oldFolderName+'-附件'
    # print(newFolderName)

    # os.rmdir('test-附件')

    os.mkdir(newFolderName)

    #3 获取old文件夹中的所有的文件名字
    fileNames=os.listdir(oldFolderName)
    # print(fileNames)

    #4、使用多进程的方式copy 原文件中的所有文件到新的文件夹中
    pool=Pool(5)
    queue=Manager().Queue()

    for name in fileNames:
        pool.apply_async(copyFileTask,args=(name,oldFolderName,newFolderName,queue))

    num=0
    allNum=len(fileNames)
    while True:
        queue.get()
        num+=1
        copyRate=num/allNum
        print('\rcopy的进度是%0.1f%%'%(copyRate*100),end='')
        if copyRate==1:
            break

    pool.close()
    pool.join()

if __name__ == '__main__':
    main()