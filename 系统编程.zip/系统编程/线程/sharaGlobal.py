from  threading import Thread
import time

#线程之间共享全局变量
g_num=100

def work1():
    global g_num
    for i in range(3):
        g_num+=1

    print('-----in work1,g_num is %d ---'%g_num)


def work2():
    global g_num
    print('-----in work2,g_num is %d ---' % g_num)

print('---线程创建之前g_num is %d---'%g_num)

t1=Thread(target=work1)
t1.start()

time.sleep(1)

#延迟一会儿
t2=Thread(target=work2)
t2.start()



print('\n---------------------------------\n')


#进程间不共享全局变量
#线程之间共享全局变量

#线程共享全局变量的问题


g_num=0
def test1():
    global g_num
    for i in range(1000000):
        g_num+=1

    print('---test1--g_num=%d' % g_num)

def test2():
    global g_num
    for i in range(1000000):
        g_num+=1

    print('---test2--g_num=%d' % g_num)

p1=Thread(target=test1)
p1.start()

time.sleep(3)    #屏蔽掉结果不一样，为什么？
'''
 g_num+=1==  g_num+1-->g_num 两句话
'''

p2=Thread(target=test2)
p2.start()

print('---g_num=%d---'%g_num)