'''
避免死锁：
    银行家算法
    添加超时时间
'''

import threading
mutexA=threading.Lock()
print(help(mutexA))
mutexA.acquire()  #默认的是永无休止的等