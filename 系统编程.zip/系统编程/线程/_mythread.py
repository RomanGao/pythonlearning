'''
使用线程完成多任务
'''
from threading import Thread
import time

'''
#1、如果多个线程执行的都是同一个函数的话，各自之间都不会影响，各是各的
def test():
    print('-----hello -----')
    time.sleep(1)

if __name__ == '__main__':
    for i in range(5):  #创建出来了5个小弟
        # test()
        t=Thread(target=test)
        t.start()

'''
                                                                                            #僵尸进程，孤儿进程
class MyThread(Thread):
    def run(self):
        #子类多线程创建
        for i in range(5):
            time.sleep(0.5)
            msg="I am "+self.name+"@"+str(i+1)   #name属性中保存的是当前线程的名字
            print(msg)
'''的、
if __name__ == '__main__': 
    t=MyThread()  #主机进程一般不结束
    t.start()
    
'''

#线程的执行顺序不确定
def test():
    for i in range(5):
        t=MyThread()
        t.start()

if __name__ == '__main__':
    test()