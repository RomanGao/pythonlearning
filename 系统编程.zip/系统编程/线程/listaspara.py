'''
列表当做参数
列表页可以全局共享
'''
import time
from threading import Thread

def work1(nums):
    nums.append(44)
    print('--------in work1-----',nums)

def work2(nums):
    #延迟一会儿
    time.sleep(1)
    print('--------in work2-----',nums)

g_num=[11,22,33]

t1=Thread(target=work1,args=(g_num,))
t1.start()

t2=Thread(target=work2,args=(g_num,))
t2.start()