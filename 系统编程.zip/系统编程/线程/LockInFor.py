from  threading import Thread, Lock
import time
g_num = 0

#等待解锁的方式是通知的方式
def test1():
    global g_num
    #这个线程和test2线程都在抢着上锁，如果1上锁成功，那么导致另外一方一直堵塞，到这个锁被解开为止
    for i in range(1000000):
        mutex.acquire()  # 上锁
        g_num += 1
        mutex.release()   #开锁

    print('---test1--g_num=%d' % g_num)


def test2():
    global g_num
    for i in range(1000000):
        mutex.acquire()  # 上锁
        g_num += 1
        mutex.release()

    print('---test2--g_num=%d' % g_num)


#上锁的代码越少越好
#所以锁可以放在for内部

# 创建一把互斥锁，这个所默认是没有上锁的
mutex = Lock()

p1 = Thread(target=test1)
p1.start()

# time.sleep(3)  # 屏蔽掉结果不一样，为什么？

p2 = Thread(target=test2)
p2.start()

print('---g_num=%d---' % g_num)

'''

'''