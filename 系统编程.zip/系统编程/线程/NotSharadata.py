'''
全局变量：修改加锁，不修改不加锁
'''

'''
多个线程使用非全局变量
'''
from  threading import Thread
import threading
import time

def work1():
    name=threading.current_thread().name
    print('-------work name is %s ---'%name)
    g_num=100
    if name=='Thread-1':
        g_num+=1
        print('-----in work1,g_num is %d ---'%g_num)

    else:
        time.sleep(1)
    print('-----thread is %s , g_num is %d ---' %(name,g_num))


# def work2():
#     time.sleep(0.5)
#     g_num=100
#     print('-----in work2,g_num is %d ---' % g_num)


t1=Thread(target=work1)
t1.start(
)
t2=Thread(target=work1)
t2.start()

#线程内部的变量是各自线程的
#非全局变量不需要加锁，各自用各自的
