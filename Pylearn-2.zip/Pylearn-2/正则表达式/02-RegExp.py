import  re

#| 或
#需求匹配出0-100之间的数字
#?1次或者0次
print(re.match(r'[1-9]\d?$|0$|100$','200'))   #None
print(re.match(r'[1-9]\d?$|0$|100$','0'))     #0
print(re.match(r'[1-9]\d?$|0$|100$','89'))    #89
print(re.match(r'[1-9]\d?$|0$|100$','100'))   #100
#讲0融入
print(re.match(r'[1-9]?\d?$|100$','0'))   #0

#（ab） （）内作为一组
result=re.match(r'<h1>(.*)</h1>','<h1>匹配分组</h1>')
print(result.group(1)) #group(num) 匹配第num个（） num默认是0：字符串全部打印
print(result.groups())  #所有（） 全部打印
# result.groups()[0] 和 result.group(1)  等价


s='<html><h1>romangao</h1></html>'
print(re.match(r'<.+><.+>.+</.+><.+>',s))
s='<html><h1>romangao</h1></h>'
print(re.match(r'<.+><.+>.+</.+><.+>',s))  #也可以匹配

s='<html><h1>romangao</h1></html>'
#\num 引用分组num匹配到的字符串
print(re.match(r'<(.+)><(.+)>.+</\2></\1>',s))  #左边产生值  右边使用


#描述一个邮箱的信息
p=r'(\w+)@(163|126|gmail|qq).(com|cn|net)$'

r=re.match(p,'roman@qq.com')
print(r)
print(r.group())   #roman@qq.com
print(r.groups())  #('roman', 'qq', 'com')


#分组起别名（？P<name>）
# (?P=name)  使用
s='<html><h1>romangao</h1></html>'
print(re.match(r'<(?P<key1>.+)><(?P<key2>.+)>.+</(?P=key2)></(?P=key1)>',s))
#先写出引用分组 再加上起别名

