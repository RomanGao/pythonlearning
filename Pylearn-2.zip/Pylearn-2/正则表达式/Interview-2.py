'''

getattr
getattribute
'''

class Foo(object):
    def __init__(self):
        self.itcast=10

    def __getattr__(self, item):
        print (item,end=' ')
        return self
    #
    # def __getattribute__(self, item):  #主线 很少去改
    #     return self.itcast    #无限嵌套

    def __str__(self):
        return ''

    def say_hello(self):
        pass

print(Foo().think.different.itcast.itheima)
#打印参数先找dict  再找getattr  这是getattribute规定的