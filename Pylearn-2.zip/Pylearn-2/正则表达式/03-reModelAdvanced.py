import re

s='<html><h1>romangao</h1></html>'

#search  寻找匹配
print(re.search(r'romangao',s))  #romangao
print(re.search(r'^romangao$',s)) #None
print(re.search(r'romangao$',s))  #None
print(re.search(r'^romangao',s))   #None

s='romangao<html><h1></h1></html>'
print(re.search(r'romangao',s))  #romangao

s='romangao</h1></html>helloworld</h1>'
r=re.search(r'\w+</h1>',s)
print(r.group())   #romangao</h1>   查找到一个就结束查找

#findall()
r=re.findall(r'\w+</h1>',s)
print(r)     #匹配到全部打印

#sub批量替换  (需要替换的部分，目的字符串，内容)
print(re.sub(r'php','python','js python c asp js php python php'))

print(re.sub(r"\d+",'50','python =1000,php=0'))

#sub第二个参数可以是一个函数
#这个函数必须有一个输入和输出
def replace(result):        #result 是拿到的匹配对象
    print(result.group())    #1000     0
    return '50'
print(re.sub(r"\d+",replace,'python =1000,php=0'))

def replace(result):
    print(result.group())
    r=int(result.group())+50
    return str(r)
print(re.sub(r"\d+",replace,'python =1000,php=0'))   #全部加50


#将<> 全部去掉
#''' ''' 这个东西占内存，内存中会存储东西，是字符串的一个特殊形式，保留文本格式，是真实存在的数据
# # 这才是真正的注释，不调入内存
s="""
<div>
        <p>岗位职责：</p>
<p>完成推荐算法、数据统计、接口、后台等服务器端相关工作</p>
<p><br></p>
<p>必备要求：</p>
<p>良好的自我驱动力和职业素养，工作积极主动、结果导向</p>
<p>&nbsp;<br></p>
<p>技术要求：</p>
<p>1、一年以上 Python 开发经验，掌握面向对象分析和设计，了解设计模式</p>
<p>2、掌握HTTP协议，熟悉MVC、MVVM等概念以及相关WEB开发框架</p>
<p>3、掌握关系数据库开发设计，掌握 SQL，熟练使用 MySQL/PostgreSQL 中的一种<br></p>
<p>4、掌握NoSQL、MQ，熟练使用对应技术解决方案</p>
<p>5、熟悉 Javascript/CSS/HTML5，JQuery、React、Vue.js</p>
<p>&nbsp;<br></p>
<p>加分项：</p>
<p>大数据，数理统计，机器学习，sklearn，高性能，大并发。</p>

        </div>
"""
print(re.sub(r'</?\w+>','',s))

#split 匹配某一个特定字符分割字符串
s='roman-gao,chang:liang_hello'
print(re.split(',|-|:|_',s))


print('====================')
#贪婪模式    尽可能多的匹配
s="this is a number 234-45-454-425"
r=re.match(r".+(\d+-\d+-\d+-\d+)",s)
print(r.group(1))    #4-45-454-425

r=re.match(r"(.+)(\d+-\d+-\d+-\d+)",s)
print(r.groups())

#关闭贪婪模式  尽可能少的匹配（(.+?)最小集合）
r=re.match(r"(.+?)(\d+-\d+-\d+-\d+)",s)
print(r.groups())


#非贪婪符？，这个操作符可以用用在“*”，“+”“？”的后面，要求正则匹配的越少越好
print(re.match(r'aa(\d+)','aa234ddd').group(1))   #234
print(re.match(r'aa(\d+?)','aa234ddd').group(1))   #2

print(re.match(r'aa(\d+)ddd','aa234ddd').group(1))  #234
print(re.match(r'aa(\d+?)ddd','aa234ddd').group(1))  #234


s=''' <img alt="张召忠的直播" data-original="https://rpic.douyucdn.cn/live-cover/roomCover/cover_update/2018/01/24/de6469335c6c331553dd2c2678e56ea6.jpg" src="https://shark.douyucdn.cn/app/douyu/res/page/list-item-def-thumb.jpg" width="283" height="163" class="JS_listthumb">
'''
print(re.search(r'https.+?\.jpg',s).group())

print(re.search(r'https.+?\.jpg',s).group())

'''
-----练习题-----
'''
#匹配网站
s="https://shark.douyucdn.cn/perform/dist/dyl.js?171030"
print(re.sub(r'https://.+?/(.*)','',s))   #替换
print(re.sub(r'(https://.+?/).*',lambda x:x.group(1),s))

#找出单词
s='hello world ha ha'
print(re.split(r' +',s))
print(re.findall((r'\b[a-zA-Z]+\b'),s))