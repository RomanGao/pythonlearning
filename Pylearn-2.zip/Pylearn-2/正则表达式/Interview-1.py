'''
构造一个类Foo
用python的魔法方法实现
（执行）print（Foo().think.diffetent.itcast.itheima)
（输出）think different itcast itheima

__init__
__str__
__new__
__del__
__call__
__repr__
__getattr__  字典中补充不上就调用他

__dict__  (魔法字典)  #对象.__dict__这是属性和和值    类.__dict__类属性和值
'''
'''
def __getattr__(self,item): 
    pass
'''

class Foo(object):
    def __init__(self):
        pass

    def __getattr__(self, item):
        print (item,end=' ')
        return self

    def __str__(self):
        return ''

    def say_hello(self):
        pass

print(Foo().think.different.itcast.itheima)
