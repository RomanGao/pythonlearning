import re

#match匹配
#result=re.match(正则表达式，要匹配的对象)  正确返回匹配对象，否则返回None(不是'')
#result.group()    返回匹配部分

pattern='itcast'
s='iterima'

print(re.match(pattern,s))

s='itcast'
print(re.match(pattern,s))

result=re.match(pattern,s)
dir(result)

print(result.group())

result=re.match('itcast','itcastithemi')
print(result.group())

'''
------字符描述----
'''

print('==================================')
#点匹配 任意 一个 字符
print(re.match('.','i'))
print(re.match('.','iffdsafads'))
print(re.match('.','\n'))   #None
print(re.match('...','fdasfadsf'))   #三个字符

#[]匹配枚举字符

#匹配数字，即0-9
print(re.match('\d','a'))
#匹配非数字
print(re.match('\D','a'))

#\s匹配非空白字符      \s \n \r
print(re.match('\s','\na'))
#\S 非

#\w  匹配单词字符即a-z  A-Z  0-9 _
print(re.match('\w','fa12'))
#\W 非
print(re.match('\w\W','1a'))

print(re.match('1[123456]','1234'))  #12
#加^取反
print(re.match('1[^12345]','18989689'))  #18

#  - 表示一个范围值
print(re.match('1[a-z5-9]','1afd56'))   #1a

'''
\d==[0-9]
\D==[^0-9]
\w==[a-zA-Z0-9_]
'''

#匹配手机号
# re.match('1[34578]\d\d\d\d\d\d\d\d\d','')

print('================')
# * 可有可无
print(re.match('\d*',''))     #''
print(re.match('\d*','adf'))  #''
print(re.match('\d*','123'))  #123

print(re.match('\d*','111'))  #111

# + 至少出现一次
print(re.match('\d+','adf'))  #None
print(re.match('\d+','123adf'))   #123

# ? 出现1次或者0次
print(re.match('\d?','abc'))  #''
print(re.match('\d?','1abc'))  #1
print(re.match('\d?','12321abc'))  #1

print(re.match('\d?\w','12321abc'))  #12

print(re.match('\d?[a-z]','12321abc'))  #None
print(re.match('\d+[a-z]','12321abc'))  #12321a
print(re.match('\d*[a-z]','12321abc'))  #12321a
'''
print(re.match('\d*','adf'))     #''
print(re.match('\d{0,}','adf')) 

print(re.match('\d+','adf'))  #None
print(re.match('\d{1,}','adf')) 

'''

#{num} 次数
print(re.match('\d{5}[a-z]','12321abc'))  #12321a
print(re.match('\d{3}[a-z]','12321abc'))  #None

#下限{num，}
print(re.match('\d{2,}','12321abc'))  #12321
print(re.match('\d{5,}]','12321abc'))  #None

#手机号
print(re.match('1[34578]\d{9}','18696450645'))
print(re.match('1[34578]\d{9}','18696asdf450645000'))


s='\\nbabc'
print(s)
print(re.match('\\\\n\w',s))


#字符串前加上r忽略到转译字符
s='\nabc'
print(s)
s=r'\nabc'
print(s)

s='\\nbabc'
print(re.match(r'\\nbabc',s))

#字符串边界
#$ 匹配字符结尾
#^ 匹配开头（match中作用不是很明显）
print(re.match('^1[34578]\d{9}$','18696450645'))
print(re.match('^1[34578]\d{9}$','1869645064500'))  #None

#单词边界
#\b 匹配一个单词的边界
print(re.match(r'^\w+ve','hover'))    #hove
print(re.match(r'^\w+\bve\b','ho ve r'))    #None
print(re.match(r'^\w+\s\bve\b','ho ve r'))  #'ho ve'  用\s表示空格
print(re.match(r'^.+\s\bve\b','ho ve r'))  #'ho ve'  用.+(除\n所有字符)表示空格
#\B
print(re.match(r'^.+\s\bve\B','ho ver'))  #ho ve
print(re.match(r'^.+\Bve\B','hover'))   #hove

