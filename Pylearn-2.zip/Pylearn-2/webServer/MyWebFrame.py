import time
from MyWebServer import HTTPSever

HTML_ROOT_DIR='./html'

class Applciation(object):
    '''框架核心的部分，也会是框架的主题程序，框架是通用的'''
    def __init__(self,urls):
        #设置路由信息
        self.urls=urls

    def __call__(self, env, start_repsonse):  #self.app(env, self.start_reponse)  # 返回的是响应体  app当做函数一样对待
        path=env.get('PATH_INFO','/')   #用get（）不会报错  '/'为默认值
        # /static/index.html  静态文件的能力
        if path.startswith('/static/'):
            #要访问静态文件
            file_name=path[7:]

            # 打开文件，读取数据
            try:
                file = open(HTML_ROOT_DIR + file_name, 'rb')
            except IOError:
                # 没找到路由信息路由错误 404
                status = '404 Not Found'
                headers = []
                start_repsonse(status, headers)
                return 'not found'
            else:
                fileData = file.read().decode('utf-8')
                file.close()

                # 构造响应数据
                status = '200 OK'
                headers = []
                start_repsonse(status, headers)
                return fileData
                # 构造响应数据

        for url,handler in self.urls:
            # ('/z_time', show_time)
            if path==url:
                return handler(env,start_repsonse)
        #没找到路由信息路由错误 404
        status='404 Not Found'
        headers=[]
        start_repsonse(status,headers)
        return 'not found'

def show_time(env,start_response):
    status = '200 OK'
    headers = [
        ("Content-Type", 'text/plain')  # 发回值有的类型
    ]
    start_response(status, headers)

    return time.ctime()  # 必须有一个返回值  作为响应体部分

def say_hello(env,start_response):
    status='200 OK'
    headers = [
        ("Content-Type", 'text/plain')  # 发回值有的类型
    ]
    start_response(status, headers)

    return 'hello world'

urls=[
        ('/',show_time),
        ('/ztime',show_time),
        ('/sayhello',say_hello)
        ]
app=Applciation(urls)


#     http_server=HTTPSever(app)
#     http_server.bind(8989)
#     http_server.start()

