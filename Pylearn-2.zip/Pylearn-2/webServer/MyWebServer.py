# 服务端
from socket import *
from multiprocessing import Process
import sys
import re

# 设置静态文件根目录
HTML_ROOT_DIR = './html'
WSGI_PYTHON_DIR = "./wsgipython"


class HTTPSever(object):
    """"""
    def __init__(self, appliacation):
        '''构造函数  application指的是框架的application'''
        self.serverSocket = socket(AF_INET, SOCK_STREAM)
        self.serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        self.app = appliacation

    def bind(self, port):
        self.serverSocket.bind(('', port))

    def start(self):
        self.serverSocket.listen(128)
        while True:
            cliSocket, cliAddr = self.serverSocket.accept()
            # print("[%s]:%s"%(cliAddr[0],cliAddr[1]))
            print('[%s]:%s' % cliAddr)

            handle_client_process = Process(target=self.handle_client, args=(cliSocket,))
            handle_client_process.start()
            cliSocket.close()

    def start_reponse(self, status, headers):  # 必须接收两个参数，分别是状态码和响应头
        '''
           status='200 OK'
    headers=[
        ("Content-Type",'text/index.html')
        ]
        '''
        server_headers = [
            ("Server", "My Server")
        ]
        headers = server_headers + headers
        response_headders = 'HTTP/1.1' + status + '\r\n'
        for header in headers:
            response_headders += '%s: %s\r\n' % header
        self.response_headers = response_headders

    def handle_client(self, cliSocket):
        """"处理客户端请求"""
        # 获取客户端请求数据
        req_data = cliSocket.recv(1024)
        print(req_data)

        # 构造响应数据
        reqLines = req_data.splitlines()
        for line in reqLines:
            print(line)

        # 解析请求报文
        # GET / HTTP/1.1
        reqStartStartLine = reqLines[0]
        # 提取用户请求的文件名
        fileName = re.match(r'\w+ +(/[^ ]*) ', reqStartStartLine.decode('utf-8')).group(1)
        method = re.match(r'(\w+) +/[^ ]* ', reqStartStartLine.decode('utf-8')).group(1)

        env = {
            'PATH_INFO': fileName,
            'METHOD': method
        }
        response_body = self.app(env, self.start_reponse)  # 返回的是响应体
        response = self.response_headers + '\r\n' + response_body

        # 向客户端响应数据
        cliSocket.send(bytes(response, 'utf-8'))  # python3必须返回字节类型

       # 关闭客户端连接
        cliSocket.close()

def main():
    sys.path.insert(1,WSGI_PYTHON_DIR)

    if (len(sys.argv))<2:
        sys.exit('python MyWebServer.py Module:app')

    #python MyWebServer.py MyWebFrameWork:app
    module_name,app_name=sys.argv[1].split(':')
    #module_name=MyWebFrameWork
    #app_name='app'

    m=__import__(module_name)
    app=getattr(m,app_name)

    http_server=HTTPSever(app)
    # http_server.setport
    http_server.bind((8989))
    http_server.start()

if __name__ == '__main__':
    main()