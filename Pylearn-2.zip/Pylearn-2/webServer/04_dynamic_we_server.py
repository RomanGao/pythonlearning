#服务端
from  socket import *
from multiprocessing import Process
import sys
import re

#设置静态文件根目录
HTML_ROOT_DIR='./html'
WSGI_PYTHON_DIR="./wsgipython"

class HTTPSever(object):
    """"""
    def __init__(self):
        self.serverSocket=socket(AF_INET,SOCK_STREAM)
        self.serverSocket.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
        #serverSocket.listen(128)

    def start(self):
        self.serverSocket.listen(128)
        while True:
            cliSocket, cliAddr = self.serverSocket.accept()
            # print("[%s]:%s"%(cliAddr[0],cliAddr[1]))
            print('[%s]:%s' % cliAddr)

            handle_client_process = Process(target=self.handle_client, args=(cliSocket,))
            handle_client_process.start()
            cliSocket.close()

    def start_reponse(self, status, headers):  # 必须接收两个参数，分别是状态码和响应头
        '''
           status='200 OK'
    headers=[
        ("Content-Type",'text/index.html')
        ]
        '''
        server_headers = [
            ("Server", "My Server")
        ]
        headers = server_headers + headers
        response_headders = 'HTTP/1.1' + status + '\r\n'
        for header in headers:
            response_headders += '%s: %s\r\n' % header
        self.response_headers = response_headders


    def handle_client(self,cliSocket):
        """"处理客户端请求"""
        # 获取客户端请求数据
        req_data = cliSocket.recv(1024)
        print(req_data)

        # 构造响应数据
        reqLines = req_data.splitlines()
        for line in reqLines:
            print(line)

        # 解析请求报文
        # GET / HTTP/1.1
        reqStartStartLine = reqLines[0]
        # 提取用户请求的文件名
        fileName = re.match(r'\w+ +(/[^ ]*) ', reqStartStartLine.decode('utf-8')).group(1)
        method=re.match(r'(\w+) +/[^ ]* ', reqStartStartLine.decode('utf-8')).group(1)

        #
        # '''
        # WSGI接口：服务器调用执行py
        # '''

        # /time.py
        if fileName.endswith('.py'):            #执行py文件
            try:
                m=__import__(fileName[1:-3])        #文件导入
            except Exception:
                self.response_headers='HTTP/1.1 404 Not Found\r\n'
                response_body='not found'
            else:
                env={
                    'PATH_INFO':fileName,
                    'METHOD':method
                }  #必须字典类型 本次执行的相关信息

            response_body=m.application(env,self.start_reponse)   #返回的是响应体
            response=self.response_headers+'\r\n'+response_body
        else:
            if '/' == fileName:
                fileName = '/index.html'

            # 打开文件，读取数据
            try:
                file = open(HTML_ROOT_DIR + fileName, 'rb')
            except IOError:
                respStart = 'HTTP/1.1 404 Not Fund\r\n'
                respHeader = 'Server:My server\r\n'
                respBody = 'the file is not found'
            else:
                fileData = file.read().decode('utf-8')
                file.close()

                # 构造响应数据
                respStart = 'HTTP/1.1 200 OK\r\n'
                respHeader = 'Server:My server\r\n'
                respBody = fileData
            finally:
                response = respStart + respHeader + "\r\n" + respBody
                print('response data:', response)

        # 向客户端响应数据
        cliSocket.send(bytes(response, 'utf-8'))  # python3必须返回字节类型

        # 关闭客户端连接
        cliSocket.close()

    def bind(self, port):
        self.serverSocket.bind(('',port))



def main():
    sys.path.insert(1,WSGI_PYTHON_DIR)
    http_server=HTTPSever()
    # http_server.setport
    http_server.bind((8989))
    http_server.start()

if __name__ == '__main__':
    main()