def appplication(env,start_resposne):
    status='404 NO Found'
    headers=[]
    start_resposne(status,headers)
    return 'file not found'