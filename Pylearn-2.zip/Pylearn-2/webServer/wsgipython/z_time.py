# import time
#
# time.ctime()
# def say_time():
#     return time.ctime()
#
# def fun_a():
#     pass
# #request必须是字典类型的
# def application(env,handle_headers):
#     # env = {
#     #     'PATH_INFO': fileName,
#     #     'QUERY_STRING': param
#     # }
#     # handle_headers(statuscode,[('Content-Type':'text/plain'),('ITcast','text/plain')]   #响应头处理函数来处理响应头
#     return ""    #规定中只能返回响应体body

import time
"ctime.py?timezone=e8"
"ctime.py?timezone=e1"

def application(env,start_response):

    #env包含用户请求的所有数据   与执行过程相关
    env={

    }
    env.get('Methond')
    env.get('PATH_INFO')

    #下面两个与返回值相关
    status='200 OK'
    headers=[
        ("Content-Type",'text/plain')   #发回值有的类型
    ]
    start_response(status,headers)
    return time.ctime()  #必须有一个返回值  作为响应体部分