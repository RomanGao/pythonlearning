#服务端
from  socket import *
from multiprocessing import Process

HTML_ROOT_DIR=''

def hangle_client(cliSocket):
    """"处理客户端请求"""
    #获取客户端请求数据
    req_data=cliSocket.recv(1024)
    print(req_data)
    respStart='HTTP/1.1 200 OK\r\n'
    respHeader='Server:My server\r\n'
    respBody='hello world'
    response=respStart+respHeader+"\r\n"+respBody
    print('response data:',response)

    #向客户端响应数据
    cliSocket.send(bytes(response,'utf-8'))

    #关闭客户端连接
    cliSocket.close()

if __name__ == '__main__':

    #TCP
    serverSocket=socket(AF_INET,SOCK_STREAM)

    addr=("",8989)
    serverSocket.bind(addr)
    serverSocket.listen(128)


    while True:
        cliSocket,cliAddr=serverSocket.accept()
        # print("[%s]:%s"%(cliAddr[0],cliAddr[1]))
        print('[%s]:%s'%cliAddr)

        handle_client_process=Process(target=hangle_client,args=(cliSocket,))
        handle_client_process.start()
        cliSocket.close()
