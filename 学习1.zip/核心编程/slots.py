'''
=============__slots__作用============

'''

class Person(object):
    __slots__ = ("name","age")     #只限制这两个属性

p=Person()
p.name='gao'
p.age=11

# p.addr='shandong'   #不能随便添加

print(p.name)
print(p.age)

