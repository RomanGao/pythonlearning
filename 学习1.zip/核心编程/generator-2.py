'''
send
'''
def test():
    i=0
    while i<5:
        temp=yield i    #并不是把i的值给temp
        print(temp)
        i+=1


t=test()

# print(t.send('haha'))  #如果是第一个调用就用send会崩，因为前边没有yield，haha传递不出去

#解决方法一：
# print(t.__next__())
# print(t.send('haha'))    #可以先调用一个next运转起来，在调用send

#解决方法二：
# print(t.send(None))


'''
print(t.__next__())
print(t.__next__())

print(t.send('haha'))    #还是从yield开始执行，但是比next高端,把haha传给temp
print(t.__next__())
'''


'''
send:可以传一个值，给yield i 表达式一个结果
    与next的相同点就是从yield接着向下执行
'''

'''
=============================
'''

def test():
    i=0
    while i<5:
        if i==0:
            temp=yield i
            print(temp)
        else:
            yield i
        i+=1

t=test()
print(t.__next__())
print(t.send('haha'))
print(t.send('haha'))
print(t.send('haha'))