'''
深拷贝和浅拷贝
'''

a=[11,22,33]
b=a   #浅拷贝  只拷贝地址，不拷贝值

print(id(a))
print(id(b))

#深拷贝
print('-------------------------')
import  copy

# C ：指向一个新的空间
c=copy.deepcopy(a)
print(id(a))
print(id(c))

a.append(44)
print('a',a)
print('b',b)
#a与B的结果相同
# C的结果不变
print('c',c)

print('=======================')

a=[11,22,33]
b=[44,55,66]
c=[a,b]  #a 嵌套这a,b
d=c  #浅拷贝
e=copy.deepcopy(c)
print(id(c))
print(id(d))
print(id(e))

a.append(44)
print(c[0])
print(e[0])


print('===========copy.deepcopy============')
a=[1,2,3]
b=[4,5,6]
c=(a,b)
e=copy.deepcopy(c)
a.append(4)
print(c[0])
print(e[0])

print('=======copy.copy================')
a=[1,2,3]
b=[4,5,6]
c=[a,b]
e=copy.copy(c)
a.append(4)
print(c[0])
print(e[0])
print(id(c))
print(id(e))

print('=================================')
a=[1,2,3]
b=[4,5,6]
c=(a,b)
e=copy.copy(c)
print(id(c))
print(id(e))
#元祖是不可变类型，所以呀id(c)=id(e)
a.append(4)
print(c[0])
print(e[0])

'''
使用copy模块的copy功能的时候，他会根据挡墙拷贝的数据类型
是否是可变类型有不同的处理方式
'''

