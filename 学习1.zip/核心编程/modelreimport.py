import sys
print(sys.path)    #import 路径
sys.path.append('/hyxd')
print(sys.path)
