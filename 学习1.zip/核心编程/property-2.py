class Test(object):
    def __init__(self):
        self.__num=100

    def setNum(self,num):
        print('----setNum---')
        self.__num=num

    def getNmu(self):
        print('-----getNum-----')
        return self.__num

    @property
    def num(self):
        return self.__num
    @num.setter
    def num(self,num):
        self.__num=num


t=Test()
t.num=200
print(t.num)

'''
    num=property(getNmu,setNum)

t=Test()
t.num=200    #相当于t.setnum=200
print(t.num)  #相当于t.getNum
'''
