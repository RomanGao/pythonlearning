#定义函数：完成包裹数据
def makeBold(fn):
    def wrapped():
        print('------1-------')
        return "<b>"+fn()+"</b>"
    return wrapped

#定义函数：完成包裹数据
def makeItalic(fn):
    def wrapped():
        print('------2-------')
        return "<i>"+fn()+"</i>"
    return wrapped

@makeBold
@makeItalic
def test3():
    print('------3-----')
    return "hello world!!"

ret=test3()
print(ret)

#========================================================================================
print('---------------------------')
def w1(func):
    print('正在装饰1。。。')
    def inner():
        print('正在验证权限1。。。')
        func()
    return inner

def w2(func):
    print('正在装饰2。。。')
    def inner():
        print('正在验证权限2。。。')
        func()
    return inner

#只要py解释器执行到这个代码的时候后，那么会自动的进行装饰，而不是调用的时候才装饰的
@w1         #f1=w1(f1)
@w2         #f1=w2(f1)
def f1():
    print('---------f1------')


#在调用f1之前，已经进行装饰了
f1()
