'''
直接作用于for循环的类型有几种：
 一类是集合数据类型，如list , tuple , dict , set , str
 一类是genertor,包括生成器和带yield的generator function
 这些作用于for循环的对象统称为可迭代对象：iteration
'''
for temp in [11,22,33,44,55]:
    print(temp)
a=[x for x in range(10)]
print(a)
b=(x for x in range(10))
print(b)

#检验是否可以迭代

#for temp in 内容      判断之一

print('===============判断二法===============')
from collections import Iterable

print(isinstance('abc',Iterable))
print(isinstance([],Iterable))
print(isinstance({},Iterable))
# print(isinstance(100,Iterable))  #不可以迭代

#判断是否迭代对象   用next()可以取值，
print('-=---------------------------')
from  collections import  Iterator
print(isinstance([],Iterator))
print(isinstance((x for x in range(10)),Iterator))

print('==============================')

a=[11,22,33,44,55,66]
b=iter(a)
print(next(b))
print(next(b))

#生成器一定是迭代器 相反不一定
a=[11,22,33,44,55,66]

