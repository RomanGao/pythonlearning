# #有返回值的装饰器
# def func(funcname):
#     print("---func--1---")
#     def func_in():
#         ret=funcname()
#         print('---func_in--2---')
#         return ret    #把haha返回到16行处
#
#     print('---func---2---')
#     return func_in
#
# @func
# def test():
#     print('---test----')
#     return 'haha'
#
# ret=test()
# print('test return value is %s'%ret)




'''
通用装饰器
'''
# def func(funcname):
#     def func_in(*args,**kwargs):
#         print('---记录日志---')
#         # ret=funcname()
#         ret=funcname(*args,**kwargs)
#         return ret
#
#     return func_in
#
# @func
# def test():
#     print('---test----')
#     return 'haha'
# @func
# def test2():
#     print('---test2---')
# @func
# def test3(a):
#     print('---test3- a=%d--'%a)
#
#
# ret=test()
# print('test return value is %s'%ret)
#
# a=test2()
# print('test2 return value is %s'%a)
#
# test3(11)

'''
带有参数的装饰器
'''
def func_arg(arg):
    def func(funcname):
        def func_in():
            print('---记录日志---%s'%arg)
            if arg=='heihei':
                funcname()
                funcname()
            else:
                funcname()
        return func_in
    return func
# @func('heihei')     #带参数的装饰器

#1、先执行func_arg("heihei")函数，这个函数reuturn的结果func这个函数的引用
#2、@func
#3、使用@func对test进行装饰
@func_arg('heihei')
def test():
    print('---test---')

#带有参数的装饰器，能够起到在运行时有不同的功能
@func_arg('哈哈')
def test2():
    print('---test2---')


test()
test2()