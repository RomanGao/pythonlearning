
#在没有参数的函数进行装饰
def func(funname):
    print('---func----1-----')
    def func_in():

        print('func_in----1----')
        funname()
        print('func_in----2----')

    print('func----2----')

    return func_in


    print('func----3----')

@func
def test():
    print('test----------')


# test=func(test)
test()


print('\n===========================\n')
#对有参数的函数进行装饰

def func(funname):
    print('---func----1-----')
    def func_in(a,b):   #如果a,b没有定义，那么会导致50行的调用失败

        print('func_in----1----')
        funname(a,b)     #如果没有把a，b当做是一餐进行传递，会导致46行失败
        print('func_in----2----')

    print('func----2----')

    return func_in

@func
def test(a,b):
    print('test-----a=%d--b=%d---'%(a,b))


test(11,22)


print('\n===========================\n')
#对不定长参数

def func(funname):
    print('---func----1-----')
    def func_in(*args,**kwargs):   #如果a,b没有定义，那么会导致50行的调用失败
        print('func_in----1----')
        funname(*args,**kwargs)     #如果没有把a，b当做是一餐进行传递，会导致46行失败
        print('func_in----2----')

    print('func----2----')

    return func_in

@func
def test(a,b,c):
    print('test-----a=%d--b=%d--c=%d-'%(a,b,c))
@func
def test2(a,b,c,d):
    print('test---a=%d--b=%d--c=%d--b=%d-----' % (a, b, c,d))


test(11,22,33)
test2(11,22,33,44)