'''
生成器--generator
不是一次性创造完成 而是在用的时候创建,一次生成一个值
通过next()调用，占用极小内存空间，产生庞大数据
'''
#列表生成式:
a=[x*2 for x in range(10)]
print(a)

#生成器创建方法1:
b=(x*2 for x in range(10))
print(next(b))


#生成器的第二种方式
print('--- 斐波那契数列 ---')
def creatNum():
    print('--start---')
    a,b=0,1
    for i in range(5):
        # print(b)
        yield b      #变成生成器
        a,b=b,a+b
    print('--stop---')

print(creatNum())  #验证是一个生成器对象
a=creatNum()

#可以放到for循环中使用
for num in a:
    print(num)

'''
#打印数据
print(next(a))    #在yield处暂停   什么时候调用什么时候生成返回值
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))

两者等价
next(a)
a.__next__()
'''

