# a=[11,22,33]
# b=[11,22,33]
# print(a==b)     #判断指向的内容
# print(a is b)  #判断是不是同一个
# c=a
# print(id(a))
# print(id(b))
# print(id(c))


a=100
b=100
print(a==b)
print(a is b)
a=1000000
b=1000000
print(a==b)
print(a is b)