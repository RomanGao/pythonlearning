# def test():
#     print('-------test---------')
#
# test()
# print(test)

# b=test
# print(b)
# b()

'''
闭包---
'''

def test(number):
    print('----1----')

    # def test_in():
    #     print('----2----')
    #     print(number+100)

    def test_in(num):
        print('----2----')
        print(number+num)

    print('----3----')
    return test_in
    # return test_in()
ret=test(100)  #----1----    ----3----
print('-'*30)
# ret()   # ----2----     200
ret(10)  #10传递的是test_in中的num

print('\n==========应用==========\n')

def test(a,b):
    def test_in(x):
        print('a*x+b=',a*x+b)
    return test_in

line1=test(1,1)
line1(0)
line2=test(10,4)
line2(0)

line1(0)