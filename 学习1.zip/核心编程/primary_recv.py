class Test(object):
    def __init__(self):
        self.__num=100

    def setNum(self,num):
        print('----setNum---')
        self.__num=num

    def getNmu(self):
        print('-----getNum-----')
        return self.__num

    num=property(getNmu,setNum)

t=Test()
# print(t.__num)   私有的不可调用

# t.__num=200  #添加了__num属性
# print(t.__num)  #打印后加添的属性

print(t.getNmu())
t.setNum(2000)
print(t.getNmu())

'''
xx:公有变量
__xx：私有
私有属性实际上名字被重整了即: _类名__属性
_xx_:系统提供的
xx_:为了预防与系统内部关键名字充满

_x：模块内部可用，模块外边不可用
from  somemodule import * 倒入不可用
但是import module 还是可用的，因为是导入的整个模块
'''
print('========================')
# t.num=10
# print(t.num)
print('-'*50)
t.num=200    #相当于t.setnum=200
print(t.num)  #相当于t.getNum

'''
t.num赋值，那么一定调用setNum()，要根据实际的场景来判断
如果是获得t.num的值，那么的就一定调用getNum()
property的作用：相当于把方法进行了封装，开发者在对属性设置数据的时候更加方便
'''
