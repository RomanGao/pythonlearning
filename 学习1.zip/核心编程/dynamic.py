'''
python 语言的动态性
'''

class Person(object):
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def eat(self):
        print('-----%s正在吃------'%self.name)


def run(self):
    print('------%s正在跑-----'%self.name)

'''
gao=Person('gao',20)
print(gao.name)
print(gao.age)
gao.addr='山东'    #给对象添加属性
print(gao.addr)

laozhang=Person('老张',12)
# print(laozhang.addr)

Person.num=100    #给类添加属性
print(gao.num)
print(laozhang.num)

'''

#添加方法
print('--------添加方法--------')

p1=Person('p1',10)
p1.eat()

# p1.run()   #崩

# p1.run=run
# p1.run()   #虽然p1对象中  run属性已经指向了第14行的函数，但是此句代码还不正确
             #因为run属性指向的函数是后来添加的，p1.run调用的时候，并不会把p1当做第一个
             #参数，导致函数调用的时候，出现缺少参数的问题
#添加的方法
import types
p1.run=types.MethodType(run,p1)  #p1.run=run(p1)与这个的结果一样子
p1.run()

#与上面结果一样子
xxx=types.MethodType(run,p1)
xxx()


#静态方法和；诶方法是跟着类走的

print('-----静态方法----')

@staticmethod
def eat():
    print('--能吃--')

Person.eat=eat
Person.eat()

print('-----类方法方法----')
@classmethod
def printNum(cls):
    print('-------class method-------')

Person.printNum=printNum
Person.printNum()

