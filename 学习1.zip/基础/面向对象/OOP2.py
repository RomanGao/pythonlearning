'''
练习***********
'''

#设计一个卖车的4S店

#版本v1.0
# class CatStore(object):
#     def order(self,car_type):
#         if car_type=='A6L':
#             return A6L()
#         elif car_type=='S6':
#             return S6()
#         elif car_type=='Q7':
#             return Q7()
#
# class Car(object):
#     def move(self):
#         print('car is moving...')
#     def music(self):
#         print('he is listening to music...')
#     def stop(self):
#         print('car is stopping...')
# class A6L(Car):
#     pass
# class S6(Car):
#     pass
# class Q7(Car):
#     pass
#
# car_store=CatStore()
# car=car_store.order('A6L')
# car.move()
# car.music()
# car.stop()

'''
升级版本********
'''
#v2.0

#3.0 简单工厂模式
# class CatStore(object):
#
#     def __init__(self):
#         self.factory=Factory()
#
#     def order(self,car_type):
#        # return select_car_by_type(car_type)
#         return self.factory.select_car_by_type(car_type)
#
# # def select_car_by_type(car_type):
# #     if car_type == 'A6L':
# #         return A6L()
# #     elif car_type == 'S6':
# #         return S6()
# #     elif car_type == 'Q7':
# #         return Q7()
# class Factory(object):
#     def select_car_by_type(car_type):
#         if car_type == 'A6L':
#             return A6L()
#         elif car_type == 'S6':
#             return S6()
#         elif car_type == 'Q7':
#             return Q7()
#
# class Car(object):
#     def move(self):
#         print('car is moving...')
#     def music(self):
#         print('he is listening to music...')
#     def stop(self):
#         print('car is stopping...')
# class A6L(Car):
#     pass
# class S6(Car):
#     pass
# class Q7(Car):
#     pass
#
# car_store=CatStore()
# car=car_store.order('A6L')
# car.move()
# car.music()
# car.stop()

'''
要求升级：上面是一个品牌的4S店，现在如果是多个品牌的4S店
'''
#工厂模式

class Store(object):
    def select_car(self):
        pass
    def order(self,car_type):
        return self.select_car(car_type)

class BMWCarStore(Store):
    def select_car(self,car_type):
        return BWMFactory.select_car_by_type(car_type)

# bmw_store=BMWCarStore()
# bmw=bmw_store.order('x6')

class CatStore(Store):
    def select_car(self,car_type):
        return Factory.select_car_by_type(car_type)

class Factory(object):
    def select_car_by_type(car_type):
        if car_type == 'A6L':
            return A6L()
        elif car_type == 'S6':
            return S6()
        elif car_type == 'Q7':
            return Q7()

class BWMFactory(object):
    def select_car_by_type(car_type):
        if car_type == 'x6':
            return A6L()
        elif car_type == 'z3':
            return S6()
        elif car_type == 'Mini':
            return Q7()


class Car(object):
    def move(self):
        print('car is moving...')
    def music(self):
        print('he is listening to music...')
    def stop(self):
        print('car is stopping...')
class A6L(Car):
    pass
class S6(Car):
    pass
class Q7(Car):
    pass

car_store=CatStore()
car=car_store.order('A6L')
car.move()
car.music()
car.stop()

'''
*******************************************
__new__：创建对象时，自动被调用，就在创建对象时使用
*******************************************
'''
'''
1.创建一个对象
2.调用__init__方法
3.返回对象的引用
'''
print('_________new______________')
class Dog(object):
    def __init__(self):      #只做初始化
        print( "初始化")
    def __del__(self):
        print( "对象释放")
    def __str__(self):
        print('----str---')
        return "对象的描述"

    #只做创建
    def __new__(cls):  #cls此时是Dog指向的那个类对象
        # print(id(cls))
        print("-----new方法-------")   #被重写，只写这句话没有创建对象
        return object.__new__(cls)       #此时，通过父类创建了对象
                                         #加了这句话，才是创建了对象
                                         #如果重写，必须加上这句话

    # __repr__=__str__

# print(id(Dog))
hsq=Dog() #相当于做个3件事情：
        #  1.调用__new__方法创建对象，然后找了一个变量来接受__new__的返回值，
#           这个返回值表示创建出来的对象的引用
        #  2.__init__(刚刚穿件出来的对象的引用)
        #  3.返回对象的引用
print(hsq)
#因为 Python 定义了__str__()和__repr__()两种方法，
# __str__()用于显示给用户，而__repr__()用于显示给开发人员。

