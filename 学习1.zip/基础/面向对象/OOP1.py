'''
********私有方法***********
'''
class Dog:

    #私有方法
    def __test1(self):
        print('******test1*********')

    #公有方法
    def test2(self):
        print('******test2*********')

dog=Dog()
# dog.__test1()   #外部用不了
dog.test2()       #外部可以的得到

class Call:

    #私有方法
    def __send_msg(self):               #比较重要，不让直接调用
        print('\n*****正在发送短信******\n')

    #公共方法    实际工作这么做，先做出判断
    def send_msg(self,money):
        if(money>=10000):
            self.__send_msg()           #调用私有函数
        else:
            print('*****余额不足，没有权限发短信*****')

client=Call()
client.send_msg(1000000)
client.send_msg(1010)


'''
*********_del***************
'''
print('***********_del************')

class Dog:

    def __del__(self):  #结束前自动执行
        print('****英雄0ver***')


dog1=Dog()
dog2=dog1  #没有创建一个额外对象，硬链接

del dog1   #dog2依然可以使用
#只删除dog1 引用没有全部删除，程序临终之前调用del

del dog2   #引用计数变成0，触发自动调用del
print('+++++++++++++++++')


'''
测试引用个数
'''
import sys
# sys.getrefcount(dog)   测试引用计数的方式
class T:
    pass
t=T()
print(sys.getrefcount(t))  #比实际个数多一个1

tt=t
print(sys.getrefcount(tt))

del t
print(sys.getrefcount(tt))


'''
调用被重写的方法***********
'''

class Dog():
    def bark(self):
        print('--------wangwang---------')

class Xiaotq(Dog):
    def fly(self):
        print('--------fly------')
    def bark(self):
        print('-------kuangjiao---------')

        #方法一
        # Dog.bark(self)  #此处的self必须要写

        #第二种
        super().bark()  #不用写self

xiaotq=Xiaotq()
xiaotq.fly()
xiaotq.bark()


'''
私有方法，私有属性在继承中的应用
'''

class A:
    def __init__(self):
        self.numl=100
        self.__num2=200

    def test1(self):
        print('******test1******')

    def __test2(self):
        print('*******test2*****')

    def test3(self):                   #允许的
        self.__test2()
        print(self.__num2)

class B(A):
    def test4(self):
        self.__test2()                 #不被允许
        print(self.__num2)

b=B()
b.test1()
# b.__test1()   #私有房啊不会被继承
print(b.numl)
# print(b.__num2)      #私有方法，私有属性都不会被继承
b.test3()           #允许被调用
# b.test4()         #不被允许

'''
如果调用的是 继承的父类中的公有方法 ：
        可以在这个公有方法中访问父类中的私有属性和私有方法
如果在子类中是先一个公有方法：
        那么这个方法是不能够调用继承的父类中的私有方法和私有属性
'''

'''
多继承*********
'''
#  类名.__mro__  多继承调用一个方法的时候，搜索的顺序，找到停止搜索
'''
多态
'''
class Dog():
    def print_self(self):
        print('-------Dog-----')

class Hsq(Dog):
    def print_self(self):
        print('________HSQ________')

def introduce(temp):
    temp.print_self()        #多态

dog1=Dog()
dog2=Hsq()
introduce(dog1)
introduce(dog2)


'''
多态强调
py 既面向过程，也面向对象
面向对象：封装、继承、多态
'''


'''
类属性，实例属性
'''
print('*********类属性，实例属性************** ')


class Tool(object):          #类对象
    # 类属性
    num = 0

    # 方法
    def __init__(self, name):
        #实例属性
        self.name = name
        Tool.num+=1

tool1 = Tool('铁锹')          #实例对象
tool2 = Tool('锤子')
tool3 = Tool('钳子')
print(Tool.num)
'''
实例属性：和具体某个实例对象有关系，
        并且一个实例对象和另外一个实例对象不共享的
类属性：类属性锁属于类对象，
        并且 多个实例对象之间共享一个类属性
'''

'''
实例方法，类方法，静态方法
'''
print('***********实例方法，类方法，静态方法****************')
class Game(object):
    # 类属性
    num = 0

    # 实例方法
    def __init__(self):  # 实例方法必须有一个参数，接受实例对象
        # 实例属性
        self.name = 'Roman'

    # 类方法
    @classmethod  # 总是对应这个类
    def add_num(cls):  # 类方法必须有一个参数，就收类
        cls.num = 100

    # 静态方法       #完成一个基本的功能，和类对象、实例对象都没有关系
    @staticmethod
    def print_menu():  # 静态方法可以没有参数
        print('*********************')
        print("         英雄联盟       ")
        print("      1,英雄联盟开始       ")
        print("      2,英雄联盟结束       ")
        print('*********************')


game = Game()
# Game.add_num()   #类方法可以通过类的名字调用类方法
game.add_num()  # 还可以通过这个类创建出来的对象，去调用这个累的方法
print(Game.num)

# Game.print_menu() #通过类调用静态方法
game.print_menu()  # 通过实例对象调用静态方法
