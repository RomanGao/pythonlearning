'''
创建实例
不管创建多少次，只创建一个对象
'''

class Dog(object):

    __instance=None
    def __new__(cls):       #cls类对象
        if cls.__instance is None:
            cls.__instance=object.__new__(cls)
            return cls.__instance
        else:
            #return 上一次创建对象的引用
            return cls.__instance

a=Dog()
b=Dog()
print(id(a))
print(id(b))

'''
只初始化一次
'''
print('\n******只初始化一次********\n')
class Dog(object):

    __instance=None
    __init_flag=False

    def __new__(cls,name):       #cls类对象
        if cls.__instance is None:
            cls.__instance=object.__new__(cls)
            return cls.__instance
        else:
            #return 上一次创建对象的引用
            return cls.__instance
    def __init__(self,name):
        #只初始化一次
        if Dog.__init_flag==False:
            self.name=name
            Dog.__init_flag==True

a=Dog('旺财')
print(id(a))
print(a.name)
b=Dog('二哈')
print(id(b))
print(b.name)

# # 此结果与上边结果不同
# a=Dog('旺财')
# b=Dog('二哈')
# print(id(a))
# print(a.name)
# print(id(b))
# print(b.name)