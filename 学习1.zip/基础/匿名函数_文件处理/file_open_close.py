'''
f=open('test.py','r')
r/rb:只能读，必须存在  ，w/wb:只写，不存在创建，如果存在，全部删掉从头写，a/ab:只写，不存在创建，追加写
r+/rb+：可以读写，必须存在  w+/wb+:可读写，不存在创建，如果存在，全部删掉从头写，a+/ab+:可以读写写，不存在创建，追加写
'''

f=open('test.py','r',encoding= 'utf-8')
# print(f.read())  #全部打印出来,读出来的是字符串
# print(f.read(1))   #只打印一个字符
# print(f.read(1))
# print(f.read(1))
# print(f.read(1))  #顺着往后读
# print(f.read(20)) #一次读20个字符
# print(f.readline())  #度一行
print(f.readlines()) #按照行全部读出，读出来的是个列表
f.close()


# f=open('test.text','w')
# f.write("def hello:")
# print(f.write("\n\ta=a+10"))  #返回写的字符个数
# f.close()