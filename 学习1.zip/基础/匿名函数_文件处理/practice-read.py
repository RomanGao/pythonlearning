f=open('xxx.txt','r',encoding='utf-8')  #open默认r
print(f.read())
f.close()