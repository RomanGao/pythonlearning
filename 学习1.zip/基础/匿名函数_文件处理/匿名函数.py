# num=[11,23,4,14,21,44,564,564,1,45,64,1121,1231,31,65,1211]
# num.sort()   #默认从小到大
# print(num)
# num.sort(reverse=True)   #从大到小
# print(num)
# num.reverse()  #逆序
# print(num)

# infors=[{"name":'gao','age':20},{"name":'roman','age':10},{"name":'hello','age':30},
#     {"name":'nihao','age':15}]
# # infors.sort()   #报错
# # infors.sort(key=lambda x:x['name'])
#
# infors.sort(key=lambda x:x['age'])
# print(infors)
#

'''
匿名函数扩展
'''

# def test(a,b,func):
#     result=func(a,b)
#     return result
#
# # num=test(11,22,lambda x,y:x+y)
# # print(num)
# func_new=input('请输入一个匿名函数：')   #python 3 中输入都当做字符串存储
#
# func_new=eval(func_new)   #转化为表达式
#
# num=test(11,22,func_new)
# print(num)

'''
完成两个变量的交换
'''
a=4
b=5

#第一种设置中间变量

#第二种不用第三个变量
# a=a+b
# b=a-b
# a=a-b

#第三种
# a,b=b,a

'''
知识点扩冲
'''
# a=100
a=[100]         #连个列表相加，合并列表

def test(num):
    # num+=num      #直接修改num的值
    num=num+num    #===>[100]+[100]==>[100,100] 开辟了一个新的弓箭
    print(num)

#= 只是引用，而不是真正的赋值
test(a)       #200
print(a)      #100