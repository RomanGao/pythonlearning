
f=open('xxx.txt','w')

f.write('hahah')

f.close()