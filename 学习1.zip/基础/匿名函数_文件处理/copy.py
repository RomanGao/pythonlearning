#1、获取用户复制的文件名
old_file_name=input("请输入要复制的文件名\n")
#2、打开要赋值的文件
old_file=open(old_file_name,'r')

poistion=old_file_name.rfind('.')
new_file_name=old_file_name[0:poistion]+'[附件]'+old_file_name[poistion::]

#3、新建一个文件
new_file=open(new_file_name,'w')
#4、从就文件中读取数据，并且写入到新文件中
content=old_file.read()
new_file.write(content)
print('复制完成*****')

#5、关闭两个文件
old_file.close()
new_file.close()