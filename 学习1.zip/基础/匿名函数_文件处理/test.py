a=[100]         #连个列表相加，合并列表

def test(num):
    # num+=num      #直接修改num的值
    num=num+num    #===>[100]+[100]==>[100,100] 开辟了一个新的弓箭
    print(num)

#= 只是引用，而不是真正的赋值
test(a)       #200
print(a)      #100