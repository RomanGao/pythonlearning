f=open('test.text')
print(f.seek(2,0))  # 第一个参数：条几个字节   第二个参数：0:开头  1：此位置  2：文件结尾
print('-----------')
print(f.readline())
print('-----------')
print(f.read())
f.seek(0,0)  #把指针拉倒第一个位置
print('-----------')
print(f.tell())   #来获取当前的位置
f.read(1)
print('-----------')
print(f.tell())