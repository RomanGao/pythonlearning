import os
# os.rename('xxx.txt','yyy.txt')   #文件重命名

# os.remove('yyy.txt')        #文件的删除

# os.mkdir('test')    #创建文件夹
# os.rmdir("test")   #删除文件夹
# os.chdir('../')  #改变默认目录
# f=open('Roman.txt','w')  #open 支持绝对和相对路径
# f.close()
# print(os.getcwd())       #获取当前绝对路径
# print(os.listdir('./'))  #获取目录列表

'''
批量重命名********
'''
# os.mkdir('test')  #创建文件夹，
#创建文件
# open('./test/利的游戏-1.avi','wb')
# open('./test/权利的游戏-2.avi','wb')
# open('./test/权利的游戏-3.avi','wb')
# open('./test/权利的游戏-4.avi','wb')
# open('./test/权利的游戏-5.avi','wb')

#1、获取需要重命名的文件夹 名字
folder_name=input('请输入要重命名的文件夹:\n')

#2、获取制定的文件夹中的所有名字
file_names=os.listdir(folder_name)

# 改变当前文件路径
os.chdir(folder_name)
#3、重命名
for name in file_names:
    print(name)

    # #若不改变当前文件路径
    # old_file_name=folder_name+'/'+name
    # new_file_name=folder_name+'/'+'[Roman]-'+name
    # os.rename(old_file_name,new_file_name)

   #讲增加的前缀删除
    # position = name.rfind('n')
    # os.rename(name,name[position::])

