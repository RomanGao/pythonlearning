'''
如果文件很大，比如5G
'''
old_file_name=input("请输入要复制的文件名\n")

old_file=open(old_file_name,'r')

poistion=old_file_name.rfind('.')
new_file_name=old_file_name[0:poistion]+'[附件]'+old_file_name[poistion::]

new_file=open(new_file_name,'w')
while True:
    content = old_file.read(1024)
    if len(content=0):
        break
    new_file.write(content)
    
print('复制完成*****')

#5、关闭两个文件
old_file.close()
new_file.close()