'''
异常处理里
'''
try:
    open('xxx.txt')
    # print(num)
    print('--------1-----')
# except NameError
except FileNotFoundError:   #产生异常的名字
    print('如果捕获到异常后做的处理。。。')

print('----2222-------')

'''
异常的基本功能
'''
print("\n------------------------")
try:
    11/0
    open('xxx.txt')
    print(num)
    print('--------1-----')
# except NameError: #产生异常的名字
#     print('如果捕获到异常后做的处理。。。')
# except FileNotFoundError:
#     print('文件不存在。。。。')
except (NameError, FileNotFoundError):
    print('捕获到异常')
# except Exception:
except Exception as retGao:
    print('用了Exception，那么以为着只要上边的except没有捕获到异常')
    print(retGao)
else:
    print('没有一场才执行这个功能')
finally:    #总会执行
    print('--------finally----')

print('----2222-------')

'''
=====================
'''
# import  time
# try:
#     f=open('test.txt')
#     try:
#         while 1:
#             content=f.readline()
#             if(len(content)==0):
#                 break
#             time.sleep(0.1)
#             print(content)
#     except Exception:
#         #如果在读取文件的过程中，产生了异常，那么就不过到
#         #比如按下Ctrl+C
#         pass
#     finally:
#         f.close()
#         print('关闭文件')
# except Exception:
#     print('没有这个文件')


'''
自定义抛异常
'''
print('\n*************自定义抛异常**************\n')
class ShortInputException(Exception):   #继承了exception
    #z自定义的异常类
    def __init__(self,length,atleast):
        #super.__init__()
        self.length=length
        self.atleast=atleast

def main():
    try:
        s=input('请输入---》')
        if len(s)<3:
            #raise引发一个你定义的异常
            raise ShortInputException(len(s),3)   #类
    except ShortInputException as result:       #类名 as 变量 对上一个行抛出异常的引用
        print('ShortInpoutException:长度是%d，至少是%d'
              %(result.length,result.atleast))
    else:
        print("没有异常产生---------")

main()

