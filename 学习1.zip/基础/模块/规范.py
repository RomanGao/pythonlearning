class T:
    pass


def M():
    pass

def main():
    pass



if __name__=='__main__':
    main()
