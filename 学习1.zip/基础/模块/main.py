import send_msg   #尽量用此，减少错误


if __name__=='__main__':
    send_msg.test1()
    send_msg.test2()
    #send_msv中的test1（）test2（）自动被调用


# from send_msg import test1,test2
# from send_msg import *
# from recvmsg import *

# if __name__=='__main__':
    # test1()               #名字相同会覆盖
    # test2()

# import time as tt
# tt.sleep(3)

