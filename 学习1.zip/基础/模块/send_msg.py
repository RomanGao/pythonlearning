def test1():
    print('********test1**********')

def test2():
    print('********test2**********')

if __name__=='__main__':
    test1()
    test2()
