import pygame
import time
from pygame.locals import *
import random
import math

def distance(x1,y1,x2,y2):
    return math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2))
# 1、搭建主背景面，主要完成窗口和背景图的显示
class HeroPlane(object):
    def __init__(self, screen_temp):
        self.x = 210
        self.y = 590
        self.screen = screen_temp
        self.image = pygame.image.load("./feiji/hero1.png")
        self.bullet_list = []  # 存储发射子弹的对象
        self.energy_list=[]   #敌人列表

    def diplay(self):
        self.screen.blit(self.image, (self.x, self.y))

        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()
            if bullet.y <= 0:
                self.bullet_list.remove(bullet)
        for enemy in self.energy_list:
            enemy.display()
            enemy.move()

    def x_inside(self,x):
        if x < 440 and x > 0:
            return True
        else:
            return False

    def y_inside(self,y):
        if y < 595 and y > 0:
            return True
        else:
            return False

    def move_left(self):
        if self.x_inside(self.x):
            self.x -= 8

    def move_right(self):
         if self.x_inside(self.x):
            self.x += 8

    def move_up(self):
        # if self.y_inside():
            self.y -= 8

    def move_down(self):
        # if self.x_inside():
            self.y += 8

    def fire(self):
        self.bullet_list.append(Bullet(self.screen, self.x, self.y))
    def creatEnemy(self):
        self.energy_list.append(Enermy(self.screen))


class Bullet(object):
    def __init__(self, screen_temp, x, y):
        self.x = x + 40
        self.y = y - 20
        self.screen = screen_temp
        self.image = pygame.image.load("./feiji/bullet.png")

    def display(self):
        self.screen.blit(self.image, (self.x, self.y))

    def move(self):
        self.y -= 10

class Enermy(object):
    def __init__(self, screen_temp):
        self.x =200
        self.y = 0
        self.screen = screen_temp
        self.image = pygame.image.load("./feiji/enemy1.png")

    def display(self):
        self.screen.blit(self.image, (self.x, self.y))

    def move(self):
        x=random.randint(-10,10)
        self.y +=5
        self.x +=x
# 获取时间比如键盘
# def checkkeybord(x,y):
#     for even in pygame.event.get():
#         #判断是否点击了退出按钮
#         if even.type==QUIT:
#             print('exit')
#             exit()
#         #判断是否按下了键
#         elif even.type==KEYDOWN:
#             #检测按键是否是a或者left
#             if even.key==K_a or even.key==K_LEFT:
#                 print("left")
#                 x-=8
#             elif even.key==K_d or even.key==K_RIGHT:
#                 print("right")
#                 x+=8
#             elif even.key==K_w or even.key==K_UP:
#                 print("UP")
#                 y-=8
#             elif even.key==K_s or even.key==K_DOWN:
#                 print("down")
#                 y+=8
#             elif even.key==K_SPACE:
#                 print("space")

def keycontrol(hero):
    for even in pygame.event.get():
        # 判断是否点击了退出按钮
        if even.type == QUIT:
            print('exit')
            exit()
        # 判断是否按下了键
        elif even.type == KEYDOWN:
            # 检测按键是否是a或者left
            if even.key == K_a or even.key == K_LEFT:
                print("left")
                # x -= 8
                hero.move_left()
            elif even.key == K_d or even.key == K_RIGHT:
                print("right")
                # x+=8
                hero.move_right()
            elif even.key == K_w or even.key == K_UP:
                print("UP")
                # y-=8
                hero.move_up()
            elif even.key == K_s or even.key == K_DOWN:
                print("down")
                # y+=8
                hero.move_down()
            elif even.key == K_SPACE:
                print("space")
                hero.fire()

def CreateEnemey(hero):
    for i in random(10):
        hero.creatEnemy()
        time.sleep(3)

def main():
    # # 1、创建一个窗口来显示内内容
    # 1.创建一个窗口
    screen = pygame.display.set_mode((480, 700), 0, 32)  # 窗口的宽高

    ## 2、创建一个和窗口大小的图片，来充当背景
    # 2.创建一个背景图片
    background = pygame.image.load("./feiji/background.png")

    # #3、把背景图片放到窗口显示
    # # -----创建一个飞机图片
    # hero1=pygame.image.load("./feiji/hero1.png");

    # 3.创建一个飞机对象
    hero1 = HeroPlane(screen)

    # x = 200
    # y = 700
    while True:
        # 设定需要显示的背景图片
        screen.blit(background, (0, 0))
        # screen.blit(hero1, (x, y))
        hero1.diplay()

        # 更新所需要显示的内容
        pygame.display.update()
        # x+=1
        # y-=1

        # checkkeybord(hero1.x,hero1.y)
        keycontrol(hero1)
        time.sleep(0.1)  # 0.01秒


if __name__ == '__main__':
    main()
