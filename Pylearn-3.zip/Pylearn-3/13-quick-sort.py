
'''
---必须记住---
'''

def quick_sort(alist,first,last):
    """快速排序"""
    mid_value = alist[first]
    low = first
    high =last
    if first==last:
        return
    while low < high:
        # high 左移动
        while low < high and alist[high] >= mid_value:
            high -= 1
        alist[low] = alist[high]

        # low 右移动
        while low < high and alist[low] < mid_value:
            low += 1

        alist[high] = alist[low]
        #从循环退出时，low==high
        alist[low]=mid_value
        # quick_sort(alist[:low-1])
        # quick_sort(alist[low+1:])      #切片是新的链表 用于原先的列表
        quick_sort(alist,first,low-1)       #对low左边的列表执行快速排序
        quick_sort(alist,low+1,last)     #对low右边的列表排序

if __name__ == '__main__':
    alist = [21, 45, 13, 42, 27, 35, 18, 19]
    print(alist)
    print('-------------')
    quick_sort(alist,0,len(alist)-1)
    print(alist)
