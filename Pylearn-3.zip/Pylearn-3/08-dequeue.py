
class Deque(object):
    '''双端队列'''

    def __init__(self):
        self.__list = []

    def add_front(self, item):
        '''往队列头部加数据'''
        self.__list.insert(0,item)  #有利于出队

    def add_rear(self, item):
        '''往队列尾部加数据'''
        self.__list.append(0, item)  # 有利于出队

    def pop_front(self):
        '''从头部提数据'''
        return self.__list.pop(0)

    def pop_rear(self):
        '''从尾部提数据'''
        return self.__list.pop()

    def is_empty(self):
        return not self.__list

    def size(self):
        return len(self.__list)

if __name__ == '__main__':
    pass
