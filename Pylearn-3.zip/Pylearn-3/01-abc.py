# 如果 a+b+c=1000，且 a^2+b^2=c^2（a,b,c 为自然数），如何求出所有a、b、c可能的组合?

# a
# b
# c
import time

start = time.time()

# 枚举法
# for a in range(0, 1001):
#     for b in range(0, 1001):
#         for c in range(0, 1001):
#             if a + b + c == 1000 and a ** 2 + b ** 2 == c ** 2:
#                 print("a, b, c:%d, %d, %d" % (a, b, c))


#T=1000*1000*1000*2     T（n）=n^3*2   g(n)=n^3
#T(n)=k*g(n)  g是T的一个渐进函数
#T(n)=O(g(n))


#计算最坏时间复杂度
#顺序  加法计算
#条件  时间复杂度最大的
#循环  乘法计算
#判断算法的效率时，取最高次数，常数项次要项忽略


# 改进  T=
for a in range(0, 1001):
    for b in range(0, 1001):
        c = 1000 - a - b
        if a ** 2 + b ** 2 == c ** 2:
            print("a, b, c:%d, %d, %d" % (a, b, c))

#T（n）=n*n(1+max(1,0)) = n^2*2=O（n^2)

#每台机器执行的时间不同
#但是执行的基本运算数量大体相同
end = time.time()
print('times:%d' % (end - start))
print('finished!!!')

#算法效率衡量
#时间复杂度：是执行的基本运算数量

