#coding:utf-8
class Queue(object):
    '''队列'''
    def __init__(self):
        self.__list=[]

    def enqueue(self,item):
        '''往队列中加数据'''
        self.__list.append(item)   #有利于入队
        # self.__list.insert(0,item)  #有利于出队

    def dequeue(self):
        '''从头部提数据'''
        return self.__list.pop(0)
        return self.__list.pop()

    def is_empty(self):
        return not self.__list

    def size(self):
        return len(self.__list)


if __name__ == '__main__':
    s=Queue()
    s.enqueue(1)
    s.enqueue(2)
    s.enqueue(3)
    print(s.dequeue())
    print(s.size())
    print(s.is_empty())