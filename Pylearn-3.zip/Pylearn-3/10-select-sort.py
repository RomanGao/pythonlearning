def select_sort(alist):
    """选择排序"""
    n = len(alist)
    for j in range(n-1):  #0~n-2
        min_index = j
        for i in range(j+1 , n):  #j+1~n-1
            if alist[min_index] > alist[i]:
                min_index = i
        alist[j], alist[min_index] = alist[min_index], alist[j]


if __name__ == '__main__':
    l = [21, 45, 13 , 42 ,27, 35, 18, 19]
    select_sort(l)
    print(l)
