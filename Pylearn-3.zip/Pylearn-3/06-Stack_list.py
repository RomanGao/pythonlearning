'''
    栈：用顺序表是实现
'''

class Stack(object):
    '''栈'''
    def __init__(self):
        self.__list=[]
#list从尾部存取  Link从头部进行存取
    def push(self,item):
        '''添加一个新元素item到栈顶'''
        self.__list.append(item)
        # self.__list.insert(0,item)  #头部添加

    def pop(self):
        '''弹出栈顶元素'''
        return  self.__list.pop()
        # self.pop(0)  #头部取

    def peek(self):
        '''返回栈顶元素'''
        if self.__list:
            return self.__list[-1]
        else:
            return None

    def is_empty(self):
        '''判断是否为空'''
        # return not self.__list
        return self.__list==[]

    def size(self):
        '''返回栈的元素个数'''
        return len(self.__list)

if __name__ == '__main__':
    s=Stack()
    s.push(1)
    s.push(2)
    s.push(3)
    s.push(4)
    print(s.pop())