
def bubble_sort(alist):
    for j in range(len(alist)-1):
        count=0    #改进
        for i in range(0,len(alist)-1-j):
            if alist[i]>alist[i+1]:
                count+=1
                alist[i],alist[i+1]=alist[i+1],alist[i]
        if 0==count:
            break

l=[2,4,3,45,42,1]
bubble_sort(l)
print(l)