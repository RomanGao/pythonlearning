
def merge_sort(alist):
    '''归并排序'''
    n=len(alist)
    mid=n//2
    if n<=1:
        return alist
    #，left才有用归并排序后形成的有序序列
    left=merge_sort(alist[:mid])
    right=merge_sort(alist[mid:])

    #将两个有序子序列合并成一个整体
    #merge(left,right)了
    left_pointer,right_pointer=0,0
    result=[]
    while left_pointer<len(left) and right_pointer<len(right):
        if left[left_pointer] <= right[right_pointer]:
            result.append(left[left_pointer])
            left_pointer+=1
        else:
            result.append(right[right_pointer])
            right_pointer+=1

    result+=left[left_pointer:]
    result+=right[right_pointer:]
    return result

if __name__ == '__main__':
    alist = [21, 45, 13, 42, 27, 35, 18, 19]
    print(alist)
    print('-------------')
    sort_li=merge_sort(alist)
    print(sort_li)
