alist = [21, 45, 13, 42, 27, 35, 18, 19]


def insert_sort(alist):
    for j in range(1, len(alist)):
        i=j
        # for i in range(i,0,-1):
        while (i):
            if alist[i] < alist[i - 1]:
                alist[i], alist[i - 1] = alist[i - 1], alist[i]
                i -= 1
            else:       #加此步进行优化
                break   #前面是有序的

if __name__ == '__main__':
    alist = [21, 45, 13, 42, 27, 35, 18, 19]
    print(alist)
    print('-------------')
    insert_sort(alist)
    print(alist)
