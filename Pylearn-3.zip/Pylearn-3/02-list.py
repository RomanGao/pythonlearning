'''
Python内置类型性能分析
timeit模块
timeit模块可以用来测试一小段Python代码的执行速度。

class timeit.Timer(stmt='pass', setup='pass', timer=<timer function>)
Timer是测量小段代码执行速度的类。

stmt参数是要测试的代码语句（statment）；

setup参数是运行代码时需要的设置；

timer参数是一个定时器函数，与平台有关。

timeit.Timer.timeit(number=1000000)
Timer类中测试语句执行速度的对象方法。number参数是测试代码时的测试次数，默认为1000000次。方法返回执行代码的平均耗时，一个float类型的秒数。
'''

import timeit

#生成列表的方法
# l1=[1,2]
# l2=[23,5]
# l=l1+l2
# l3=[i for i in range(1000)]
# # l4=[range(10000)]  python2 是列表   python3是可迭代对象


from timeit import Timer
#测试
def test1():
    li=[]
    for i in range(10000):
        li.append(i)
def test2():
    l=[]
    for i in range(10000):
        # l+=[i]  python有优化1.6s
        l=l+[i]      #218 S   不能用
def test3():
    l=[x for x in range(10000)]  #第二块
def test4():   #最快
    list(range(10000))
def test5():   #最慢
    li = []
    for i in range(10000):
        li.extend([i])


# time1=Timer('test1()','from __main__ import test1')
# print('append:',time1.timeit(1000) ) #测算1000次 返回花费了多少秒
#
# time2=Timer('test2()','from __main__ import test2')
# print('+:',time2.timeit(1000) )
#
# time3=Timer('test3()','from __main__ import test3')
# print('[x for x in range]:',time3.timeit(1000) )
#
# time4=Timer('test4()','from __main__ import test4')
# print('list(range()):',time4.timeit(1000) )
#
# time5=Timer('test5()','from __main__ import test5')
# print('extent():',time5.timeit(1000) )

'''
append: 1.0474392995302957
+: 1.069446077306207     这两个差不多 效率都不高
[x for x in range]: 0.46148125754615377
list(range()): 0.2692533063118039
extent(): 1.7394978996732413
'''

# append()只能添加一个元素
# extent([])  添加一个列表

def test6():
    li = []
    for i in range(10000):
        li.append(i)
def test7():
    li = []
    for i in range(10000):
        li.insert(0,i)   #从头添加

# time6=Timer('test6()','from __main__ import test6')
# print('append:',time6.timeit(1000) )
#
# time7=Timer('test7()','from __main__ import test7')
# print('insert（0,i）:',time7.timeit(1000) )
'''
append比insert快的多
append: 1.1417869852519926
insert（0,i）: 35.46529655568805
'''