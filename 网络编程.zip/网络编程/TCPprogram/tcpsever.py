from socket import *

#创建Tcp
serverSocket=socket(AF_INET,SOCK_STREAM)

serverSocket.bind(('',8899))

serverSocket.listen(5)  #监听

#新的客户端    新的客户端的ip以及port
ClientSocket,ClientAddr=serverSocket.accept() #接听   返回值是一个元组

recvData=ClientSocket.recv(1024)

print("%s:%s"%(str(ClientAddr),recvData.decode('gb2312')))

ClientSocket.close()
serverSocket.close()