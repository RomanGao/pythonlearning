from socket import *

connNum=int(input('请输入要链接服务器的个数：'))
addr=('192.168.48.1',8899)

for i in range(connNum):
    s=socket(AF_INET,SOCK_STREAM)
    s.connect(addr)
    print(i)