from socket import *
from time import sleep

#创建socket
tcpSocket=socket(AF_INET,SOCK_STREAM)

#绑定本地信息
addr=('',8899)
tcpSocket.bind(addr)

connNum=int(input('请输入要最大的连接数：'))

#使用socket创建的桃姐子默认是用自动的，要通过listen变为本栋
tcpSocket.listen(connNum)


for i in range(10):     #在这个期间，如果有20个客户调用了connect链接服务器，那么这个服务器的Linux底层会自动维护2个队列（半连接和已连接）
    print(i)            #
    sleep(0.5)          #其中半连接和已连接的数为listen中的值，如果这哥值为5 那么，意味着此时最多有5个客户端能够链接成功，而剩余的15个堵塞在connect函数中


while True:
    newSocket,clientAddr=tcpSocket.accept()
    #如果按服务器调用了accept，那么在Linux底层中的那个半连接和已连接的中的客户单的个数就少一个，
    # 因此此时那15个因为connect堵塞客服端又会在进行链接；来争抢这个1个空出来的位置

    print(clientAddr)
    sleep(0.5)

