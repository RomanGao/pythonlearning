from socket import *

#创建套接字
clientsocket=socket(AF_INET,SOCK_STREAM)

#链接服务器
setAddr=('192.168.48.1',8989)

clientsocket.connect(setAddr)

#1、tcp客户端已经链接好了服务器，所以在以后的发送数据中，不需要添加对方的ip和port----------》打电话
#2、udp在发送数据的时候，因为没有之前的链接，友谊需要每此发送的时候都要填写接受方的ip和port------》写信
clientsocket.send('haha'.encode('gb2312'))

recvData=clientsocket.recv(1024)
print('recvData:%s'%recvData.decode('gb2312'))

clientsocket.close()