'''
单线程非堵塞服务器
'''
from socket import *

#创建套接字
serverSocket=socket(AF_INET,SOCK_STREAM)

#绑定本地套接字
localAddr=("",8899)
serverSocket.bind(localAddr)

#让socket变为非堵塞
serverSocket.setblocking(False)

#变为被动，接听
serverSocket.listen(5)

#用来保存所有已经链接的客户端
clientAddrList=[]

while True:

    #等待一个新的客户端的到来（即完成三次握手的客户端）
    try:
        clientSocket,clientAddr=serverSocket.accept()
    except:
        pass
    else:
        print('一个新的客户端到来：%s'%(str(clientAddr)))
        clientSocket.setblocking(False)
        clientAddrList.append((clientSocket,clientAddr))

    for clientSocket,clientAddr in clientAddrList:
        try:
            recvData=clientSocket.recv(1014)
        except:
            pass
        else:
            if len(recvData)>0:
                print("%s:%s"%(str(clientAddr),recvData.decode('gb2312')))
            else:
                clientSocket.close()
                clientAddrList.remove((clientSocket,clientAddr))
                print('%s已经下线'%(str(clientAddr)))