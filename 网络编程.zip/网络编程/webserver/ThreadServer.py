from multiprocessing import Process
from threading import *
from socket import *


def test(newSocket,destaddr):
    print('子进程处理等待新客户的到来---')
    while True:
        recvData=newSocket.recv(1024)
        if len(recvData)>0:
            print('recv[%s]:%s'%(str(destaddr),recvData.decode('gb2312')))
        else:
            print('[%s]客户已经关闭'%(str(destaddr)))
            break
    newSocket.close()
    #newSocket被close，那么意味着：这个套接字不在使用recv和send来接发数据

def main():

    serSocket=socket(AF_INET,SOCK_STREAM)

    #重复使用绑定信息
    serSocket.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)

    localAddr=('',8899)
    serSocket.bind(localAddr)

    serSocket.listen(5)
    print('主进程，等待客户')
    try:
        while True:
            newSocket,destaddr=serSocket.accept()

            #进程
            # p=Process(target=test,args=(newSocket,destaddr))
            # p.start()
            # newSocket.close() #子进程已经拷贝了一份，所以可以关

            #线程
            client=Thread(target=test,args=(newSocket,destaddr))
            client.start()
            #newSocket().close()  #线程共享同一进程资源，所以不能关
    finally:
        serSocket.close()
        #如果serSock被close，那么意味着：不能在接受新的客户端连接

if __name__ == '__main__':
    main()

'''
多进程多线程？
    如果没有多进程。多线程，难么任务是单任务，即在为一个顾客服务的时候，不能通化市为其他顾客服务
'''