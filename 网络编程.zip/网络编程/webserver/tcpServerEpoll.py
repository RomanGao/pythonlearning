import socket
import select

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR)

s.bind(("",8989))

s.listen(10)

#创建epoll对象
epoll = select.epoll()

#文件描述符（fd)
epoll.register(s.fileno(),select.EPOLLIN|select.EPOLLET)
'''
epoll.register(文件句柄,事件类型) 注册要监控的文件句柄和事件
事件类型:
　　select.EPOLLIN    可读事件

　　select.EPOLLOUT   可写事件
    
    select.EPOLLET    ET模式  
    
    LT模式（水平触发，默认模式）：只有处理完才不触发，只要没处理就不断通知
    ET模式（边缘触发）：只会有一次通知的机会，效率高，没有通知以后就不处理
    
　　select.EPOLLERR   错误事件

　　select.EPOLLHUP   客户端断开事件

epoll.unregister(文件句柄)   销毁文件句柄
'''
connections={}
address={}
                              #框架三个重要步骤：
                                      # 1 、 先创建监听套接字
while True:

    #epoll进行id扫描的地方--未指定超时则为堵塞等待
    epoll_list=epoll.poll()      # 相当于readable, writeable, exceptional = select.select(inputs, [], [])
                                      #  2 、通过某些方式来检测那些套接字可以进行收发了

    #对事件进行判断
    for fd ,event in epoll_list:      # 3 、 对上面检测的套接字进行收发处理

        #如果有socket创建的套接字被激活
        if fd==s.fileno():
            conn,addr=s.accept()
            print('有新的客户端到来%s'%str(addr))

            #讲conn和addr信息分别保存起来
            connections[conn.fileno()]=conn
            address[conn.fileno()]=addr

            #向epoll中注册 链接socket的可读事件
            epoll.register(conn.fileno(),select.EPOLLIN|select.EPOLLET)

        #判断事件是否是接受数据的事件
        elif event==select.EPOLLIN:
            #根据文件描述符找到对应的套接字,因为文件描述符不能recv
            #只有套接字可以
            recvData=connections[fd].recv(1024)

            if len(recvData)>0:
                print('recv:%s'%recvData)
            else:
                epoll.unregister(fd)
                connections[fd].close()

                print('%s--offline---'%str(address[fd]))

'''
sys.stdin  --》键盘   标准输入
sys.stdou  --》屏幕  标准输出
sys.stderr --》屏幕  标准错误
'''

'''
epoll效率最高
poll和select算法一样只把相率改了 效率是一样子
单进程非堵塞最慢
'''