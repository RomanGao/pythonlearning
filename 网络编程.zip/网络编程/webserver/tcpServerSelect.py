'''
select版服务器
select可以完成一些套接字的检测
把从头到尾所有的套接字全部检测完成之后 做一个返回
'''

'''
import select
readable,writeable,exceptional=select.select(list1,list2,list3)
list1:检测这个列表中的套接字是否可以接收数据
list2:检测这个列表中的套接字可否发数据
list3:检测这个列表中的套接字是否产生了异常
'''

import select,socket,sys

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind('',8989)
server.listen(5)

inputs = [server, sys.stdin]

running=True

while True:
    #select函数，堵塞等待
    readable, writeable, exceptional = select.select(inputs, [], [])

    #数据抵达，循环
    for sock in readable:

        #监听到新的链接
        if socket==server:
            conn,addr=server.accept()
            #select监听socket
            inputs.append(conn)

        #监听到键盘有输入
        elif sock==sys.stdin:
            cmd=sys.stdin.readline()
            running=False
            break
        #有数据到达
        else:
            #读取客户端连接发送的数据
            data=sock.recv(1024)
            if data:
                sock.send(data)
            else:
                #移除select监听的socket
                inputs.remove(sock)
                sock.close()

    #如果检测到用户输入敲击键盘就退出
    if not running:
        break
server.close()


'''
select良好的夸平台效果
32位 1024个
64位 2048个
以轮询的方式进行检测

poll-->解决了套接字有上限的问题  和select几乎一样子
也是以轮询的方式进行检测

epoll--》没有上限，---事件通知机制（不是轮询机制）
'''