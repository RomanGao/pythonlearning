import gevent

'''
def f(n):
    for i in range(n):
        for i in range(n):
            print(gevent.getcurrent(), i) 

'''

def f(n):
    for i in range(n):
        print(gevent.getcurrent(), i)  # 遇到耗时操作，自动切换协程
        # 用来模拟一个耗时操作
        gevent.sleep(1)


g1 = gevent.spawn(f, 5)
g2 = gevent.spawn(f, 5)
g3 = gevent.spawn(f, 5)

g1.join()
g2.join()
g3.join()

'''
如果遇到耗时，就切换协程
'''