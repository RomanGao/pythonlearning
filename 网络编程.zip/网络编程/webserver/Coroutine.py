'''
协程：IO密集型
减少大量CPU的切换，提高效率
在一个线程里边，把一个线程劈成多份  

计算机密集型：大量占用CPU   --》用多进程
IO密集型：需要网络功能，大量时间都在等待网络数据的到来-》用多线程，协程

python的多线程GIL 不管有几个核的CPU 都只用一个核
'''

import time

def A():
    while True:
        print('---A---')
        yield
        time.sleep(0.5)

def B(c):
    while True:
        print('---B---')
        next(c)
        time.sleep(0.5)

if __name__ == '__main__':
    a=A()
    B(a)

#协程只通过切换函数完成多任务