from socket import *

def main():
    udpsocket=socket(AF_INET,SOCK_DGRAM)

    udpsocket.bind(('',8686))

    #收 打印
    while True:
        recvinfo=udpsocket.recvfrom(1024)

        # udpsocket.sendto(recvinfo[0],recvinfo[1])  #echo服务器  多了这一句话
         #怎么发过来就怎么发回去

        print('[%s]=%s'%(str(recvinfo[1]),recvinfo[0].decode('utf-8')))

if __name__ == '__main__':
    main()