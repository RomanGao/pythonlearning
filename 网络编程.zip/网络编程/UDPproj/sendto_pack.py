from socket import *
import struct
import os


def main():

    # downloadFileName=input('请输入要下载的文件名：')

    downloadFileName='test.jpg'

    # sendData = struct.pack("!H8sb5sb", 1, b"test.jpg", 0, b"octet", 0)
    sendData = struct.pack("!H%dsb5sb"%(len(downloadFileName)), 1, downloadFileName.encode('utf-8'), 0, b"octet", 0)

    udpSocket=socket(AF_INET,SOCK_DGRAM)

    udpSocket.sendto(sendData,('192.168.1.105',69))

    flag=True #表示能够下载数据，即不擅长，如果是fals e那么就删除
    num=0
    f=open(downloadFileName,'w')

    while True:
        responseData=udpSocket.recvfrom(1024)
        recvData,severInfo=responseData

        opNum=struct.unpack('!H',recvData[:2])

        packNum=struct.unpack("!H",recvData[2:4])

        # print(opNum+packNum)
        print(packNum[0])

        if opNum[0]==3:  #因为optNum此时是一个元组（3，），所以需要使用下边聊提取数据

            #计算出这次应该就收的文件的序号值，应该是上一次接受到的值得基础上+1
            num=num+1

        #如果一个下载的文件特别大，即接受到的数据包编号超过2的字节的大小
        #那么会从0继续开始，所以这里需要判断，如果超过了65535，那么就改为0
        if num==65536:
            num=0

        #判断这次接受到的数据包的编号是否是上一次的包编号的下一个
        #如果是才会写入到文件中，否则不会写入（因为会重复用）

        if num==packNum[0]:
            f.write(recvData[4:])
            num=packNum[0]

        elif opNum==5:
            print('没有这个文件！！！')
            flag=False

        if len(recvData)<516:
            break

    if flag==True:
        f.close()
    else:
        os.unlink(downloadFileName)   #如果没有下载的文件，那么就需要把刚刚创建的文件给删除


if __name__ == '__main__':
    main()