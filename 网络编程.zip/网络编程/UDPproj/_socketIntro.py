import socket

#TCP
st=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print('Socket Created---TCP')

#UDP
su=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
print('Socket Created---UDP')