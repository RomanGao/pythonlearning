from socket import *

#1、创建套接字
udpsocket=socket(AF_INET,SOCK_DGRAM)

#使用UDP发送的数据，在每一次的是都语言协商接受方的ip和pot
# udpsocket.sendto(b'haha',('192.168.48.1',8080))

#绑定bind
udpsocket.bind(('',8686))  #我的端口   绑定一般绑定在接受的一方

# udpsocket.sendto(b'hello',('192.168.48.1',8080))

#接收数据
while True:
    recvData=udpsocket.recvfrom(1024)
    print(recvData)
#一般接收方需要绑定，收不需要绑定
