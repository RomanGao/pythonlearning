from socket import *

udpsocket=socket(AF_INET,SOCK_DGRAM)

'''
destIp=input('请输入目的IP:')
destPort=int(input('请输入母的端口：'))
sendData=input('请输入要发送的数据：')

# udpsocket.sendto(sendData.encode('gb2312'),(destIp,destPort))

udpsocket.sendto(sendData.encode('utf-8'),(destIp,destPort))
'''


udpsocket.bind(('',8686))
recvData=udpsocket.recvfrom(1024)

content,destInfo=recvData

print('content is %s'%content)
print('conten is %s'%content.decode('utf-8'))   #解码