from threading import Thread
from socket import *

# 线程共享全局变量

#1、收数据，然后打印
def recvData():
    while True:
        recvinfo=udpSocket.recvfrom(1024)
        print('\r')
        print('>>%s : %s'%(str(recvinfo[1]),recvinfo[0].decode('gb2312')))

#2、检查键盘，发数据
def sendData():
    while True:
        sendInfo=input('<<')
        sendInfo=sendInfo+'\n'
        udpSocket.sendto(sendInfo.encode('gb2312'),(destIp,destPort))

udpSocket=None  #创建全局变量
destIp=""
destPort=0

def main():
    global udpSocket  #全局的
    global destIp
    global destPort

    # destIp=input('对方的ip：')
    # destPort = int(input('对方的端口：'))

    destIp='192.168.48.1'
    destPort=8080

    udpSocket=socket(AF_INET,SOCK_DGRAM)
    udpSocket.bind(('',8686))

    tr=Thread(target=recvData)
    ts=Thread(target=sendData)

    tr.start()
    ts.start()

    tr.join()
    ts.join()

if __name__ == '__main__':
    main()