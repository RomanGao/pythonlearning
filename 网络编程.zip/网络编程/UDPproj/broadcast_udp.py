'''
udp广播
'''
from socket import *
import socket,sys

dest=('<broadcast>',7788)

#创建udp套接字
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

#如果s套接字需要发送广播数据，那么需要这句话
s.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)

#以广播的形式发送数据到本网络的所有电脑
s.sendto(b'Hi',dest)

print('等待对方回复！')

while True:
    (buf,address)=s.recvfrom(1024)
    print('Received from %s:%s'%(address,buf))
